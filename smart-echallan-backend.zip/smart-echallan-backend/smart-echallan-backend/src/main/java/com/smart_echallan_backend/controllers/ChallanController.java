package com.smart_echallan_backend.controllers;

import com.smart_echallan_backend.dto.ChallanDTO;
import com.smart_echallan_backend.entities.Challan;
import com.smart_echallan_backend.services.ChallanService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/challan")
 @CrossOrigin(origins = "http://localhost:5173") // allow frontend access
public class ChallanController {

    @Autowired
    private ChallanService service;

    //  Create challan
    @PostMapping("/add")
    public Challan createChallan(@Valid @RequestBody ChallanDTO dto) {

        return service.create(dto);
    }

    //  Pay challan
    @PutMapping("/pay/{id}")
    public Challan payChallan(@PathVariable Long id) {

        return service.pay(id);
    }

    // Get all challans
    @GetMapping("/all")
    public List<Challan> getAllChallans() {

        return service.getAll();
    }
}