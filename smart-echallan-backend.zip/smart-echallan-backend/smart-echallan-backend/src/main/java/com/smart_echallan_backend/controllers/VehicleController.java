package com.smart_echallan_backend.controllers;

import com.smart_echallan_backend.dto.VehicleDTO;
import com.smart_echallan_backend.entities.Vehicle;
import com.smart_echallan_backend.services.VehicleService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

 @CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/vehicle")

public class VehicleController {

    @Autowired
    private VehicleService service;

    @PostMapping("/add")
    public Vehicle add(@Valid @RequestBody VehicleDTO dto) {

        return service.save(dto);
    }

    @GetMapping("/all")
    public List<Vehicle> getAll() {

        return service.getAll();
    }

}
