package com.smart_echallan_backend.controllers;

import com.smart_echallan_backend.dto.ViolationDTO;
import com.smart_echallan_backend.entities.Violation;
import com.smart_echallan_backend.services.ViolationService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/violation")
  @CrossOrigin(origins = "http://localhost:5173") // allow frontend access

public class ViolationController {

    @Autowired
    private ViolationService service;

    // Add new violation
    @PostMapping("/add")
    public Violation addViolation(@Valid @RequestBody ViolationDTO dto) {

        return service.save(dto);
    }

    // Get all violations
    @GetMapping("/all")
    public List<Violation> getAllViolations() {

        return service.getAll();
    }
}