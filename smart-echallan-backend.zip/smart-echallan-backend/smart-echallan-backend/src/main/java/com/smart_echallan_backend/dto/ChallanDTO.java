package com.smart_echallan_backend.dto;


import jakarta.validation.constraints.NotNull;

public class ChallanDTO {


    @NotNull(message = "Vehicle ID is required")
    private Long vehicleId;

    @NotNull(message = "Violation ID is required")
    private Long violationId;


    public Long getVehicleId() {

        return vehicleId;
    }

    public void setVehicleId(Long vehicleId) {

        this.vehicleId = vehicleId;
    }

    public Long getViolationId() {

        return violationId;
    }

    public void setViolationId(Long violationId) {

        this.violationId = violationId;
    }
}
