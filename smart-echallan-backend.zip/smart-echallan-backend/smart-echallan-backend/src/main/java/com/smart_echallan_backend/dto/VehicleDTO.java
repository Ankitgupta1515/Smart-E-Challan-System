package com.smart_echallan_backend.dto;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class VehicleDTO {

    @NotBlank(message = "Vehicle number is required")
    @Pattern(regexp = "^[A-Z]{2}[0-9]{1,2}[A-Z]{1,2}[0-9]{3,4}$",
            message = "Invalid vehicle number (e.g., UP14AB1234)")

    private String vehicleNumber;

    @NotBlank(message = "Owner name is required")
    @Size(min = 3, max = 100, message = "Owner name must be 3–100 characters")

    private String ownerName;


    @Pattern(regexp = "^[0-9]{10}$", message = "Owner contact must be 10 digits")
    private String ownerContact;


    public String getVehicleNumber() {

        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {

        this.vehicleNumber = vehicleNumber;
    }

    public String getOwnerName() {

        return ownerName;
    }

    public void setOwnerName(String ownerName) {

        this.ownerName = ownerName;
    }
    public String getOwnerContact() {

        return ownerContact;
    }

    public void setOwnerContact(String ownerContact) {

        this.ownerContact = ownerContact;
    }
}
