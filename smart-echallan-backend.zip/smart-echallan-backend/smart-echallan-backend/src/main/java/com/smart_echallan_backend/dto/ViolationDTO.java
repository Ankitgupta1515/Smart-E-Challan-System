package com.smart_echallan_backend.dto;


import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

public class ViolationDTO {

    @NotBlank(message = "Rule name is required")
    private String ruleName;

    @Min(value = 1, message = "Fine must be at least 1")
    private Double fineAmount;


    public String getRuleName() {

        return ruleName;
    }

    public void setRuleName(String ruleName) {

        this.ruleName = ruleName;
    }

    public Double getFineAmount() {

        return fineAmount;
    }

    public void setFineAmount(Double fineAmount) {

        this.fineAmount = fineAmount;
    }
}
