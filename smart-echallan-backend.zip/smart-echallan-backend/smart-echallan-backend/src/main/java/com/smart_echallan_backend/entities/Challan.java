package com.smart_echallan_backend.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "challans")
public class Challan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Vehicle vehicle;

    @ManyToOne
    private Violation violation;

    private String status;

  public Challan()
  {}

    // Constructor without id
    public Challan(Vehicle vehicle, Violation violation, String status) {
        this.vehicle = vehicle;
        this.violation = violation;
        this.status = status;
    }

    // If you also need with ID
    public Challan(Long id, Vehicle vehicle, Violation violation, String status) {

        this.id = id;
        this.vehicle = vehicle;
        this.violation = violation;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public Violation getViolation() {
        return violation;
    }

    public void setViolation(Violation violation) {
        this.violation = violation;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
