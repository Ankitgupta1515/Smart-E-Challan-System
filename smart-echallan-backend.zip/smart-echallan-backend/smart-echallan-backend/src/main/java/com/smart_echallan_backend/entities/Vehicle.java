package com.smart_echallan_backend.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "vehicles")
public class Vehicle
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "vehicle_number")
    private String vehicleNumber;

    @Column(name = "owner_name")
    private String ownerName;

    @Column(name = "owner_contact")
    private String ownerContact;


    public Vehicle()
    {}

    public Vehicle(String vehicleNumber, String ownerName, String ownerContact) {

        this.vehicleNumber = vehicleNumber;
        this.ownerName = ownerName;
        this.ownerContact = ownerContact;
    }

    public Vehicle(Long id, String vehicleNumber, String ownerName, String ownerContact) {

        this.id = id;
        this.vehicleNumber = vehicleNumber;
        this.ownerName = ownerName;
        this.ownerContact = ownerContact;
    }



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getOwnerContact() {
        return ownerContact;
    }

    public void setOwnerContact(String ownerContact) {
        this.ownerContact = ownerContact;
    }
}
