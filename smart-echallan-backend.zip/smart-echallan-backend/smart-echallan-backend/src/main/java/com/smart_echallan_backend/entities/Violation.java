package com.smart_echallan_backend.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "violations")
public class Violation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String ruleName;

    private Double fineAmount;

    public Violation()
    {}


    public Violation(String ruleName, Double fineAmount) {

        this.ruleName = ruleName;
        this.fineAmount = fineAmount;
    }

    public Violation(Long id, String ruleName, Double fineAmount) {

        this.id = id;
        this.ruleName = ruleName;
        this.fineAmount = fineAmount;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    public Double getFineAmount() {
        return fineAmount;
    }

    public void setFineAmount(Double fineAmount) {
        this.fineAmount = fineAmount;
    }
}
