package com.smart_echallan_backend.repositories;

import com.smart_echallan_backend.entities.Challan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ChallanRepository extends JpaRepository<Challan, Long> {

}
