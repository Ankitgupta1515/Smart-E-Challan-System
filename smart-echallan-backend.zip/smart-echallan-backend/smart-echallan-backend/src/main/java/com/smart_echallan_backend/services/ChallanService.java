package com.smart_echallan_backend.services;


import com.smart_echallan_backend.dto.ChallanDTO;
import com.smart_echallan_backend.entities.Challan;
import com.smart_echallan_backend.entities.Vehicle;
import com.smart_echallan_backend.entities.Violation;
import com.smart_echallan_backend.repositories.ChallanRepository;
import com.smart_echallan_backend.repositories.VehicleRepository;
import com.smart_echallan_backend.repositories.ViolationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ChallanService {

    @Autowired
    private ChallanRepository challanRepo;

    @Autowired
    private VehicleRepository vehicleRepo;

    @Autowired
    private ViolationRepository violationRepo;

    // Create a new challan using DTO
    public Challan create(ChallanDTO dto) {

        Vehicle vehicle = vehicleRepo.findById(dto.getVehicleId())
                .orElseThrow(() -> new RuntimeException("Vehicle not found"));

        Violation violation = violationRepo.findById(dto.getViolationId())
                .orElseThrow(() -> new RuntimeException("Violation not found"));

        Challan challan = new Challan(vehicle, violation, "PENDING");

        return challanRepo.save(challan);
    }

    // Pay a challan
    public Challan pay(Long id) {

        Challan challan = challanRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Challan not found"));

        challan.setStatus("PAID");
        return challanRepo.save(challan);
    }

    // Get all challans
    public List<Challan> getAll() {

        return challanRepo.findAll();
    }
}
