package com.smart_echallan_backend.services;

import com.smart_echallan_backend.dto.VehicleDTO;
import com.smart_echallan_backend.entities.Vehicle;
import com.smart_echallan_backend.repositories.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VehicleService {

    @Autowired
    private VehicleRepository repository;

    public Vehicle save(VehicleDTO dto) {

        Vehicle v = new Vehicle(dto.getVehicleNumber(), dto.getOwnerName(), dto.getOwnerContact());

        return repository.save(v);
    }

    public List<Vehicle> getAll() {
        return repository.findAll();
    }

}
