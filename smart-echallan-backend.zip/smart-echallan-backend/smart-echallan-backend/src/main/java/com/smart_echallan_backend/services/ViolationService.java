package com.smart_echallan_backend.services;

import com.smart_echallan_backend.dto.ViolationDTO;
import com.smart_echallan_backend.entities.Violation;
import com.smart_echallan_backend.repositories.ViolationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ViolationService {

    @Autowired
    private ViolationRepository repository;


    // Save violation using DTO
    public Violation save(ViolationDTO dto) {

        Violation violation = new Violation(dto.getRuleName(), dto.getFineAmount());

        return repository.save(violation);
    }

    // Get all violations
    public List<Violation> getAll() {

        return repository.findAll();
    }
}
