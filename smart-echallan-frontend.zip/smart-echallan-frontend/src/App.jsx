
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Vehicles from "./pages/Vehicles";
import Violations from "./pages/Violations";
import Challans from "./pages/Challans";

export default function App() {
  return (
    <BrowserRouter>
      <div className="flex h-screen">
        {/* Sidebar */}
        <aside className="w-64 bg-gray-900 text-white p-5">
          <h2 className="text-xl font-bold mb-5">🚦 Smart E-Challan</h2>
          <nav className="flex flex-col gap-3">
            <Link to="/" className="hover:text-yellow-400">Dashboard</Link>
            <Link to="/vehicles" className="hover:text-yellow-400">Vehicles</Link>
            <Link to="/violations" className="hover:text-yellow-400">Violations</Link>
            <Link to="/challans" className="hover:text-yellow-400">Challans</Link>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 bg-gray-100 overflow-y-auto">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/vehicles" element={<Vehicles />} />
            <Route path="/violations" element={<Violations />} />
            <Route path="/challans" element={<Challans />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}
