import { useEffect, useState } from "react";
import axios from "axios";

export default function ChallanList() {
  const [challans, setChallans] = useState([]);

  useEffect(() => {
    // Correct URL (replace port if needed)
    axios.get("http://localhost:8080/challan/all")
      .then(res => setChallans(res.data))
      .catch(err => console.error(err));
  }, []);

  const payChallan = (id) => {
    axios.put(`http://localhost:8080/challan/pay/${id}`)
      .then(() => {
        alert("Challan Paid!");
        setChallans(challans.map(c =>
          c.id === id ? { ...c, status: "PAID" } : c
        ));
      })
      .catch(err => console.error(err));
  };

  return (
    <div className="card">
      <h2>Challans</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Vehicle</th>
            <th>Violation</th>
            <th>Fine</th>
            <th>Status</th>
            <th>Pay</th>
          </tr>
        </thead>
        <tbody>
          {challans.map(c => (
            <tr key={c.id}>
              <td>{c.id}</td>
              <td>{c.vehicle?.vehicleNumber}</td>
              <td>{c.violation?.ruleName}</td>
              <td>₹{c.violation?.fineAmount}</td>
              <td>{c.status}</td>
              <td>
                {c.status === "PENDING" && (
                  <button
                    onClick={() => payChallan(c.id)}
                    style={{ padding: "5px 10px", backgroundColor: "#27ae60", color: "white", border: "none", borderRadius: "4px", cursor: "pointer" }}
                  >
                    Pay
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
