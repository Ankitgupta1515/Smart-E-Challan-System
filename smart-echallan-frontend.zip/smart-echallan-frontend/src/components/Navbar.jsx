import { Link, useLocation } from "react-router-dom";

export default function Navbar() {
  const location = useLocation();

  return (
    <nav className="navbar">
      <h2 style={{ color: "white" }}>Smart E-Challan</h2>
      <div>
        <Link style={{ textDecoration: location.pathname === "/" ? "underline" : "none" }} to="/">Dashboard</Link>
        <Link style={{ textDecoration: location.pathname === "/vehicles" ? "underline" : "none" }} to="/vehicles">Vehicles</Link>
        <Link style={{ textDecoration: location.pathname === "/violations" ? "underline" : "none" }} to="/violations">Violations</Link>
        <Link style={{ textDecoration: location.pathname === "/challans" ? "underline" : "none" }} to="/challans">Challans</Link>
      </div>
    </nav>
  );
}
