import { useEffect, useState } from "react";
import axios from "axios";

export default function VehicleList() {
  const [vehicles, setVehicles] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:8080/vehicle/all").then(res => setVehicles(res.data)).catch(err => console.error(err));
  }, []);

  return (
    <div className="card">
      <h2>Vehicles</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Vehicle Number</th>
            <th>Owner Name</th>
          </tr>
        </thead>
        <tbody>
          {vehicles.map(v => (
            <tr key={v.id}>
              <td>{v.id}</td>
              <td>{v.vehicleNumber}</td>
              <td>{v.ownerName}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
