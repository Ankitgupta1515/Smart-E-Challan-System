import { useEffect, useState } from "react";
import axios from "axios";

export default function ViolationList() {
  const [violations, setViolations] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:8080/violation/all").then(res => setViolations(res.data)).catch(err => console.error(err));
  }, []);

  return (
    <div className="card">
      <h2>Violations</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Rule Name</th>
            <th>Fine Amount (₹)</th>
          </tr>
        </thead>
        <tbody>
          {violations.map(v => (
            <tr key={v.id}>
              <td>{v.id}</td>
              <td>{v.ruleName}</td>
              <td>₹{v.fineAmount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
