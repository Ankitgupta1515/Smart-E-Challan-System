
import { useState, useEffect } from "react";
import axios from "axios";

export default function Challans() {
  const [challans, setChallans] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [violations, setViolations] = useState([]);
  const [form, setForm] = useState({ vehicleId: "", violationId: "" });

  // Load challans, vehicles, and violations
  useEffect(() => {
    fetchChallans();
    axios.get("http://localhost:8080/vehicle/all").then(res => setVehicles(res.data));
    axios.get("http://localhost:8080/violation/all").then(res => setViolations(res.data));
  }, []);

  const fetchChallans = () => {
    axios.get("http://localhost:8080/challan/all").then(res => setChallans(res.data));
  };

  const createChallan = () => {
    if (!form.vehicleId || !form.violationId) return alert("Select Vehicle and Violation");
    axios.post(`http://localhost:8080/challan/create/${form.vehicleId}/${form.violationId}`)
      .then(() => {
        setForm({ vehicleId: "", violationId: "" });
        fetchChallans();
      });
  };

  const payChallan = (id) => {
    axios.put(`http://localhost:8080/challan/pay/${id}`).then(() => fetchChallans());
  };

  return (
    <div>
      <h1 className="text-xl font-bold mb-3">📑 Manage Challans</h1>

      {/* Challan Create Form */}
      <div className="mb-4 flex gap-2">
        <select
          value={form.vehicleId}
          onChange={e => setForm({ ...form, vehicleId: e.target.value })}
          className="border p-2"
        >
          <option value="">Select Vehicle</option>
          {vehicles.map(v => (
            <option key={v.id} value={v.id}>{v.vehicleNumber} - {v.ownerName}</option>
          ))}
        </select>

        <select
          value={form.violationId}
          onChange={e => setForm({ ...form, violationId: e.target.value })}
          className="border p-2"
        >
          <option value="">Select Violation</option>
          {violations.map(v => (
            <option key={v.id} value={v.id}>{v.ruleName} (₹{v.fineAmount})</option>
          ))}
        </select>

        <button onClick={createChallan} className="bg-green-500 text-white px-4">Generate</button>
      </div>

      {/* Challan Table */}
      <table className="w-full border">
        <thead>
          <tr className="bg-gray-200">
            <th>ID</th><th>Vehicle</th><th>Owner</th><th>Violation</th><th>Fine</th><th>Status</th><th>Action</th>
          </tr>
        </thead>
        <tbody>
          {challans.map(c => (
            <tr key={c.id} className="border">
              <td>{c.id}</td>
              <td>{c.vehicle?.vehicleNumber}</td>
              <td>{c.vehicle?.ownerName}</td>
              <td>{c.violation?.ruleName}</td>
              <td>₹{c.violation?.fineAmount}</td>
              <td className={c.status === "PENDING" ? "text-red-600" : "text-green-600"}>
                {c.status}
              </td>
              <td>
                {c.status === "PENDING" && (
                  <button
                    onClick={() => payChallan(c.id)}
                    className="bg-blue-500 text-white px-3 py-1 rounded"
                  >
                    Pay
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
