import { useEffect, useState } from "react";
import axios from "axios";

export default function Dashboard() {
  const [vehicles, setVehicles] = useState([]);
  const [violations, setViolations] = useState([]);
  const [challans, setChallans] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:8080/vehicle/all").then(res => setVehicles(res.data)).catch(err => console.error(err));
    axios.get("http://localhost:8080/violation/all").then(res => setViolations(res.data)).catch(err => console.error(err));
    axios.get("http://localhost:8080/challan/all").then(res => setChallans(res.data)).catch(err => console.error(err));
  }, []);

  const paid = challans.filter(c => c.status === "PAID").length;
  const pending = challans.filter(c => c.status === "PENDING").length;

  return (
    <div>
      <h1>📊 Dashboard</h1>
      <div style={{ display: "flex", gap: "20px", flexWrap: "wrap" }}>
        <div className="card">
          <h3>Vehicles</h3>
          <p>{vehicles.length}</p>
        </div>
        <div className="card">
          <h3>Violations</h3>
          <p>{violations.length}</p>
        </div>
        <div className="card">
          <h3>Challans</h3>
          <p>📑 Total: {challans.length}</p>
          <p>✅ Paid: {paid}</p>
          <p>⚠ Pending: {pending}</p>
        </div>
      </div>
    </div>
  );
}
