import { useState, useEffect } from "react";
import axios from "axios";

export default function Vehicles() {
  const [vehicles, setVehicles] = useState([]);
  const [form, setForm] = useState({ vehicleNumber: "", ownerName: "", ownerContact: "" });

  useEffect(() => {
    fetchVehicles();
  }, []);

  const fetchVehicles = () => {
    axios.get("http://localhost:8080/vehicle/all")
      .then(res => setVehicles(res.data));
  };

  const addVehicle = () => {
    axios.post("http://localhost:8080/vehicle/add", form).then(() => {
      setForm({ vehicleNumber: "", ownerName: "", ownerContact: "" });
      fetchVehicles();
    });
  };

  return (
    <div>
      <h1 className="text-xl font-bold mb-3">🚗 Manage Vehicles</h1>

      {/* ✅ Form */}
      <div className="mb-4 flex gap-2">
        <input placeholder="Vehicle No" value={form.vehicleNumber}
          onChange={e => setForm({ ...form, vehicleNumber: e.target.value })}
          className="border p-2" />
        <input placeholder="Owner Name" value={form.ownerName}
          onChange={e => setForm({ ...form, ownerName: e.target.value })}
          className="border p-2" />
        <input placeholder="Owner Contact" value={form.ownerContact}
          onChange={e => setForm({ ...form, ownerContact: e.target.value })}
          className="border p-2" />
        <button onClick={addVehicle} className="bg-blue-500 text-white px-4">Add</button>
      </div>

      {/* ✅ Vehicles Table */}
      <h2 className="text-lg font-semibold mt-6 mb-2">All Vehicles</h2>
      <table className="w-full border">
        <thead>
          <tr className="bg-gray-200">
            <th>ID</th>
            <th>Owner Name</th>
            <th>Owner Contact</th>
            <th>Vehicle Number</th>
          </tr>
        </thead>
        <tbody>
          {vehicles.map(v => (
            <tr key={v.id} className="border">
              <td>{v.id}</td>
              <td>{v.ownerName}</td>
              <td>
                {/* ✅ Clickable Contact */}
                <a 
                  href={`tel:${v.ownerContact}`} 
                  className="text-blue-600 underline hover:text-blue-800"
                >
                  {v.ownerContact}
                </a>
              </td>
              <td>
                {/* ✅ Clickable Vehicle Number */}
                <a 
                  href={`/vehicle/${v.id}`} // change to v.vehicleNumber if needed
                  className="text-green-600 underline hover:text-green-800"
                >
                  {v.vehicleNumber}
                </a>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
