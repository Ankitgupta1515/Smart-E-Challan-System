
import { useState, useEffect } from "react";
import axios from "axios";

export default function Violations() {
  const [violations, setViolations] = useState([]);
  const [form, setForm] = useState({ ruleName: "", fineAmount: "" });

  useEffect(() => {
    fetchViolations();
  }, []);

  const fetchViolations = () => {
    axios.get("http://localhost:8080/violation/all")
      .then(res => setViolations(res.data));
  };

  const addViolation = () => {
    if (!form.ruleName || !form.fineAmount) return alert("Enter rule name and fine");
    axios.post("http://localhost:8080/violation/add", {
      ruleName: form.ruleName,
      fineAmount: parseFloat(form.fineAmount)
    }).then(() => {
      setForm({ ruleName: "", fineAmount: "" });
      fetchViolations();
    });
  };

  return (
    <div>
      <h1 className="text-xl font-bold mb-3">🚦 Manage Violations</h1>

      {/* Add Violation Form */}
      <div className="mb-4 flex gap-2">
        <input
          placeholder="Rule Name"
          value={form.ruleName}
          onChange={e => setForm({ ...form, ruleName: e.target.value })}
          className="border p-2"
        />
        <input
          placeholder="Fine Amount"
          type="number"
          value={form.fineAmount}
          onChange={e => setForm({ ...form, fineAmount: e.target.value })}
          className="border p-2"
        />
        <button
          onClick={addViolation}
          className="bg-green-500 text-white px-4"
        >
          Add
        </button>
      </div>

      {/* Violations Table */}
      <table className="w-full border">
        <thead>
          <tr className="bg-gray-200">
            <th>ID</th><th>Rule</th><th>Fine (₹)</th>
          </tr>
        </thead>
        <tbody>
          {violations.map(v => (
            <tr key={v.id} className="border">
              <td>{v.id}</td>
              <td>{v.ruleName}</td>
              <td>₹{v.fineAmount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
